using UnityEngine;

//***********************************************************************************
// Contributed by author jl-randazzo github.com/jl-randazzo
//***********************************************************************************
namespace NavMeshPlus.Extensions
{
    [System.Serializable]
    public class NavMeshAgentAttribute : PropertyAttribute
    {
    }
}
